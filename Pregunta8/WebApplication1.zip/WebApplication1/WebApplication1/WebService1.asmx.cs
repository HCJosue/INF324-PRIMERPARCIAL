﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    /// <summary>
    /// Descripción breve de WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos";
        }

        [WebMethod]
        public string HolaMundo()
        {
            return "Hola a todos";
        }

        [WebMethod]
        public int suma(int a, int b)
        {
            return a+b;
        }

        [WebMethod]
        public DataSet dspersona()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";
            SqlDataAdapter ada = new SqlDataAdapter();
            ada.SelectCommand = new SqlCommand();
            ada.SelectCommand.Connection = con;
            ada.SelectCommand.CommandText = "select ci,nombre,paterno,extension,edad from persona xp where xp.estado=1";
            ada.SelectCommand.CommandType = CommandType.Text;
            DataSet ds = new DataSet();
            ada.Fill(ds, "persona");
            return ds;
        }

        [WebMethod]
        public void eliminar(int ci) {
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            string sql;
            con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";
            cmd.Connection = con;
            sql = "update persona set estado=0 where ci="+ci;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        [WebMethod]
        public void agregar(int ci, String nombre,String paterno,String extension,int edad) {
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            string sql;
            con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";
            cmd.Connection = con;
            sql = "insert into persona values("+ci+",'"+nombre+"','"+paterno+"','"+extension+"',"+edad+",1)";
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        [WebMethod]
        public void actualizar(int ci,String nombre,String paterno,int edad) {
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            string sql;
            con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";
            cmd.Connection = con;
            sql = "update persona set nombre='"+nombre+"',paterno='"+paterno+"',edad="+edad+" where ci="+ci;
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}
