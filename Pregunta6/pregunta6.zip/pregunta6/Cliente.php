<?php
    session_start();
    include("conexion.php");
    $resultado=mysqli_query($con,"select nroCuenta,tipo,monto from cuentabancaria where ciUsuario=".$_SESSION["ci"]." and estado=1");
    $resultado2=mysqli_query($con,"select nombre,paterno from persona where ci=".$_SESSION["ci"]);
    $fila2=mysqli_fetch_array($resultado2);
    include("cabecera.php");
?>
    <h3>Bienvenido <?php echo $fila2["nombre"]." ".$fila2["paterno"]?> </br> Tienes el rol de: <?php echo $_SESSION["rol"]?> </br> Le mostramos sus cuentas </h3>
    <table class="table">
  <thead>
    <tr class="thead-dark">
      <th scope="col">Numero de Cuenta</th>
      <th scope="col">Tipo</th>
      <th scope="col">Monto</th>
    </tr>
  </thead>
  <tbody>
<?php
while($fila=mysqli_fetch_array($resultado)){
    echo "<tr>";
    echo "<td>".$fila["nroCuenta"]."</td><td>".$fila["tipo"]."</td>";
    echo "<td>".$fila["monto"]."</td>";
    echo "</tr>";
}
?>
</tbody>
</table> 
<?php
    include("pie.php");
?>