<?php
    session_start();
    include("conexion.php");
    $resultado2=mysqli_query($con,"select nombre,paterno from persona where ci=".$_SESSION["ci"]);
    $fila2=mysqli_fetch_array($resultado2);
    include("cabecera.php");
?>
     <h3>Bienvenido <?php echo $fila2["nombre"]." ".$fila2["paterno"]?> </br> Tienes el rol de: <?php echo $_SESSION["rol"]?> </br> Visualizamos los montos existentes por departamento(agregados), dando la vuelta al resultado (CASE-WHEN) </h3>
     <table class="table">
  <thead>
    <tr class="thead-dark">
      <th scope="col">La Paz</th>
      <th scope="col">Beni</th>
      <th scope="col">Cochabamba</th>
      <th scope="col">Oruro</th>
      <th scope="col">Santa Cruz</th>
      <th scope="col">Tarija</th>
      <th scope="col">Potosi</th>
      <th scope="col">Sucre</th>
      <th scope="col">Pando</th>
    </tr>
  </thead>
  <tbody>
<?php
$resultado=mysqli_query($con,"select sum(case when extension='LP' then monto else 0 end) LaPaz,
sum(case when extension='BN' then monto else 0 end) Beni,
sum(case when extension='CBBA' then monto else 0 end) Cochabamba,
sum(case when extension='OR' then monto else 0 end) Oruro,
sum(case when extension='SCZ' then monto else 0 end) SantaCruz,
sum(case when extension='TRJ' then monto else 0 end) Tarija,
sum(case when extension='PT' then monto else 0 end) Potosi,
sum(case when extension='CH' then monto else 0 end) Sucre,
sum(case when extension='PA' then monto else 0 end) Pando
from (select xp.extension,sum(xc.monto) monto
from persona xp,cuentabancaria xc
where xp.ci=xc.ciUsuario and xc.estado=1 and xp.estado=1
group by xp.extension) tablita");
while($fila=mysqli_fetch_array($resultado)){
    echo "<tr>";
    echo "<td>".$fila["LaPaz"]."</td><td>".$fila["Beni"]."</td><td>".$fila["Cochabamba"]."</td><td>".$fila["Oruro"]."</td><td>".$fila["SantaCruz"]."</td><td>".$fila["Tarija"]."</td><td>".$fila["Potosi"]."</td><td>".$fila["Sucre"]."</td><td>".$fila["Pando"]."</td>";
    echo "</tr>";
}
?>
</tbody>
</table> 
<?php
    include("pie.php");
?>