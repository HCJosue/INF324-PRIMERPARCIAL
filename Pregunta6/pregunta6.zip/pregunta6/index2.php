<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css"/>
    <title>Document</title>
</head>
<body>
<form action="Verificar.php"  method="post" name="formDatosPersonales">

	<label for="nombre">Usuario</label>
	<input type="text" name="usuario" id="usuario"/>

	<label for="apellidos">Password</label>
	<input type="password" name="pass" id="pass"/>
	<h3><?php if(isset($_GET['error'])){echo "Usuario o Password incorrecta";}?></h3>
	<input type="submit" name="enviar" value="Entrar"/>
</form>

</body>
</html>