<?php
    include("conexion.php");
    $usuario=$_POST['usuario'];
    $pass=$_POST['pass'];
    $pass=md5($pass);
    echo $pass;
    $resultado=mysqli_query($con,"select * from usuario where usuario='".$usuario."' and pass='".$pass."'");
    $fila=mysqli_fetch_array($resultado);
    if(empty($fila)){
        header("Location: index.php?error=si");
    }
    else{
        session_start();
        $resultado2=mysqli_query($con,"select xr.descripcion from rol xr,usuario xp where xp.nro=".$fila["nro"]." and xp.rol=xr.idrol");
        $fila2=mysqli_fetch_array($resultado2);
        $_SESSION["ci"]=$fila['nro'];
        $_SESSION["rol"]=$fila2['descripcion'];
        if($fila2['descripcion']=="Director"){
            header("Location: Director.php");
        }
        if($fila2['descripcion']=="Cliente"){
            header("Location: Cliente.php");
        }
        if($fila2['descripcion']=="Operador"){
            header("Location: Operador.php");
        }
    }
?>