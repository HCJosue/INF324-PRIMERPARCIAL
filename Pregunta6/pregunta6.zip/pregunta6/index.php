<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="bootstrap.min.css" rel="stylesheet">
    <style>
        body{
            background: #002b68;
            background: linear-gradient(to right,#002b68,#f8e1c2);
        }
        .bg{
            background-image: url(imagen.jpg);
            background-position: center center;
        }
        h3{
            color: red;
        }
    </style>
</head>
<body>
    <div class="container w-75 bg-primary mt-5 rounded shadow">
        <div class="row align-items-stretch">
            <div class="col bg d-none d-lg-block col-md-5 col-lg-5 col-xl-6 rounded">
                
            </div>
            <div class="col bg-white p-5 rounded-end">
                <h2 class="fw-blod text-center py-5">Bienvenido</h2>
                <form action="Verificar.php" method="POST">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Usuario</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="usuario" placeholder="Usuario">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="pass">
                    </div>
                    <div class="form-group">
                        <h3><?php if(isset($_GET['error'])){echo "Usuario o Password incorrecta";}?></h3>
                    </div>
                    <hr class="sidebar-divider">
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" name="Login"/>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="bootstrap.bundle.min.js"></script>
</body>
</html>