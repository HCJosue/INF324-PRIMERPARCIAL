﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5(String ci)
        {
            InitializeComponent();
            textBox2.Text = ci;
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Crear_Click(object sender, EventArgs e)
        {
            DateTime t2 = DateTime.Today;
            String fecha = t2.ToString("yyyy-MM-dd");
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            string sql;
            con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";
            cmd.Connection = con;
            sql = "insert into cuentabancaria values('"+comboBox1.Text+"','"+fecha+"',"+textBox1.Text+",1,"+textBox2.Text+")";
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            this.Close();
        }
    }
}
