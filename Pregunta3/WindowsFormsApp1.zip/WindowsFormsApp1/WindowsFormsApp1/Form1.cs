﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            llenar();
        }
        private void llenar() {
            SqlConnection con = new SqlConnection();
            SqlDataAdapter ada = new SqlDataAdapter();
            DataSet ds = new DataSet();
            con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";

            ada.SelectCommand = new SqlCommand();
            ada.SelectCommand.Connection = con;
            ada.SelectCommand.CommandText = "select ci,nombre,paterno,extension,edad from persona where estado=1";

            ada.Fill(ds);

            this.dataGridView1.DataSource = ds.Tables[0];
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
            llenar();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int nrofila = e.RowIndex;
            int ci = Convert.ToInt32(this.dataGridView1.Rows[nrofila].Cells[0].Value);
            MessageBoxButtons f = MessageBoxButtons.YesNo;
            DialogResult t= MessageBox.Show("Desea eliminar el numero de carnet "+ci,"Eliminar",f);
            if (t==DialogResult.Yes) {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                string sql;
                con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";
                cmd.Connection = con;
                sql = "update persona set estado=0 where ci="+ci;
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                llenar();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                String nrocuenta = this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                String nombre = this.dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                String apellido = this.dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                String edad = this.dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                Form3 f = new Form3(Convert.ToInt32(nrocuenta),nombre,apellido,Convert.ToInt32(edad));
                f.ShowDialog();

            }
            catch {
                MessageBox.Show("Selecciona una fila por favor");
            }
            llenar();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                String nrocuenta = this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                String nombre = this.dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                String apellido = this.dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                Form4 f = new Form4(Convert.ToInt32(nrocuenta), nombre, apellido);
                f.ShowDialog();

            }
            catch
            {
                MessageBox.Show("Seleccione una celda porfavor") ;
            }
        }
    }
}
