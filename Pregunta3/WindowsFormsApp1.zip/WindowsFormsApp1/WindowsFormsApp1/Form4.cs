﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4(int ci,String nombre,String paterno)
        {
            InitializeComponent();
            textBox1.Text = ci + "";
            label1.Text = "Lista de las cuentas que tiene el usuario "+nombre+" "+paterno;
            llenar();
        }
        public void llenar() {
            SqlConnection con = new SqlConnection();
            SqlDataAdapter ada = new SqlDataAdapter();
            DataSet ds = new DataSet();
            con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";

            ada.SelectCommand = new SqlCommand();
            ada.SelectCommand.Connection = con;
            ada.SelectCommand.CommandText = "select nrocuenta,tipo,fechaA,monto from cuentabancaria where estado=1 and ciUsuario="+textBox1.Text;

            ada.Fill(ds);

            this.dataGridView1.DataSource = ds.Tables[0];
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int nrofila = e.RowIndex;
            int ci = Convert.ToInt32(this.dataGridView1.Rows[nrofila].Cells[0].Value);
            MessageBoxButtons f = MessageBoxButtons.YesNo;
            DialogResult t = MessageBox.Show("Desea eliminar la cuenta  " + ci, "Eliminar", f);
            if (t == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                string sql;
                con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";
                cmd.Connection = con;
                sql = "update cuentabancaria set estado=0 where nrocuenta="+ci+" and ciUsuario=" + textBox1.Text;
                cmd.CommandText = sql;
                cmd.CommandType = CommandType.Text;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                llenar();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 f = new Form5(textBox1.Text);
            f.ShowDialog();
            llenar();
        }
    }
}
