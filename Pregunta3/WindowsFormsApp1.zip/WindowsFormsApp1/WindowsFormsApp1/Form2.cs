﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime t2 =DateTime.Today;
            String fecha = t2.ToString("yyyy/MM/dd");
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            string sql;
            con.ConnectionString = "server=(local);user=u324;pwd=123456;database=bdjosue";
            cmd.Connection = con;
            sql = "insert into persona";
            sql = sql + " values(" + textBox1.Text + ",'" + textBox2.Text + "','" + textBox3.Text + "','"+comboBox1.Text+"',"+textBox6.Text+",1);";
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
