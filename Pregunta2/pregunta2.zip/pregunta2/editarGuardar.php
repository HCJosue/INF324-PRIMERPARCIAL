<?php
    include "conexion.php";
    if (isset($_GET["Cancelar"]))
        header("Location: index.php");
    $ci=$_GET["ci"];
    $nombre=$_GET["nombre"];
    $paterno=$_GET["paterno"];
    $edad=$_GET["edad"];
    mysqli_query($con,"update persona set nombre='$nombre' , paterno='$paterno', edad='$edad' where ci='$ci'");
    header("Location: index.php");
?>