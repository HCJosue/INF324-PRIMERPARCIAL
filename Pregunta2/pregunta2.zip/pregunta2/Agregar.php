<?php
    include("cabecera.php");
?>
    <div class="container">
        <h1>Formulario para agregar una persona</h1>
        <form action="agregarGuardar.php" method="GET">
            <div class="form-group">
                <label for="exampleFormControlInput1">Numero de Carnet</label>
                <input type="number" class="form-control" id="ci" name="ci"/>
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">Extension</label>
                <select class="form-control" id="extension" name="extension">
                <option>LP</option>
                <option>SCZ</option>
                <option>PT</option>
                <option>OR</option>
                <option>CB</option>
                <option>BN</option>
                <option>PA</option>
                <option>TRJ</option>
                <option>CH</option>
                </select>
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre"/>
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">Apellido</label>
                <input type="text" class="form-control" id="paterno" name="paterno"/>
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">Edad</label>
                <input type="number" class="form-control" id="edad" name="edad"/>
            </div>
            <input type="submit" class="btn btn-primary" value="Aceptar" name="Aceptar"/>
            <input type="submit" class="btn btn-primary" value="Cancelar" name="Cancelar"/>
        </form>
    </div>
<?php
    include("pie.php");
?>