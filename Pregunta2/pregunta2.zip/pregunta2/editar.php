<?php
    include("conexion.php");
    include("cabecera.php");
    $ci=$_GET["ci"];
    $resultado=mysqli_query($con,"select * from persona where ci=$ci");
    $fila=mysqli_fetch_array($resultado);
?>
    <div class="container">
    <h1>Formulario para editar Datos de <?php echo $fila["nombre"].' '.$fila["paterno"]?></h1>
        <form action="editarGuardar.php" method="GET">
            <input type="hidden" class="form-control" id="ci" name="ci" value="<?php echo $fila["ci"]?>"/>
            <div class="form-group">
                <label for="exampleFormControlInput1">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo $fila["nombre"]?>"/>
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">Apellido</label>
                <input type="text" class="form-control" id="paterno" name="paterno" value="<?php echo $fila["paterno"]?>"/>
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">Edad</label>
                <input type="number" class="form-control" id="edad" name="edad" value="<?php echo $fila["edad"]?>"/>
            </div>
            <input type="submit" class="btn btn-primary" value="Aceptar" name="Aceptar"/>
            <input type="submit" class="btn btn-primary" value="Cancelar" name="Cancelar"/>
        </form>
    </div>
<?php 
    include("pie.php");
?>