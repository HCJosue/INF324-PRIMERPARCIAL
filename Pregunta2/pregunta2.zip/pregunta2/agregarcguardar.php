<?php
    include "conexion.php";   
    $tipo=$_GET["tipo"];
    $monto=$_GET["monto"];
    $fecha=date('Y-n-j');
    $ci=$_GET["ci"];
    if (isset($_GET["Cancelar"]))
        header("Location: verc.php?ci=".$ci);
    mysqli_query($con,"insert into cuentabancaria values(NULL,'$tipo','$fecha',$monto,1,$ci)");
    header("Location: verc.php?ci=".$ci);
?>