<?php
    include("cabecera.php");
    include("conexion.php");
    $ci=$_GET['ci'];
    $nroc=$_GET['nrocuenta'];
    $resultado=mysqli_query($con,"select * from persona where ci=$ci");
    $fila=mysqli_fetch_array($resultado);
?>
    <div class="Container">
    <h1>Transaccion de <?php echo $fila["nombre"].' '.$fila["paterno"]?> de la cuenta <?php echo $nroc;?></h1>
    <div class="card">
        <div class="card-body">
            <a href="verc.php?ci=<?php echo $ci;?>"><i class="fa-solid fa-backward fa-2xl" style="color: #031d49;"></i></a>
        </div>
    </div>
    <table class="table">
        <thead class="thead-dark">
            <tr>
            <th scope="col">Numero de transaccion</th>
            <th scope="col">Tipo</th>
            <th scope="col">Fecha</th>
            <th scope="col">Monto</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $resultado=mysqli_query($con,"select * from transaccion where nroCuenta=$nroc ");
                $eliminar='<i class="fa-solid fa-trash fa-2xl" style="color: #ff0000;"></i>';;
                while($fila=mysqli_fetch_array($resultado)){
                    echo "<tr>";
                    echo "<td>".$fila["idTra"]."</td><td>".$fila["tipo"]."</td><td>".$fila["fecha"]."</td><td>".$fila["montoS"]."</td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
    </div>
<?php
    include("pie.php");
?>