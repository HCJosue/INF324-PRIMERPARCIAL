<?php
    include("conexion.php");
    $ci=$_GET["ci"];
    $nrocuenta=$_GET["nrocuenta"];
    if (isset($_GET["Cancelar"]))
        header("Location: verc.php?ci=".$ci);
    $monto=$_GET["monto"];
    $tipo=$_GET["tipo"];
    $fecha=date('Y-n-j');
    if($tipo=="Deposito"){
        mysqli_query($con,"insert into transaccion values(NULL,'$tipo','$fecha',$monto,$nrocuenta)");
        mysqli_query($con,"update cuentabancaria set monto=monto+$monto where nroCuenta=$nrocuenta");
        header("Location: verc.php?ci=".$ci);
    }
    else{
        $resultado=mysqli_query($con,"select monto from cuentabancaria where nroCuenta=$nrocuenta");
        $montoc=mysqli_fetch_array($resultado);
        if($montoc["monto"]>=$monto){
            mysqli_query($con,"insert into transaccion values(NULL,'$tipo','$fecha',$monto,$nrocuenta)");
            mysqli_query($con,"update cuentabancaria set monto=monto-$monto where nroCuenta=$nrocuenta");
            header("Location: verc.php?ci=".$ci);
        }
        else{
            header("Location: hacerT.php?ci=".$ci."&nrocuenta=$nrocuenta&error=si");
        }
    }
?>