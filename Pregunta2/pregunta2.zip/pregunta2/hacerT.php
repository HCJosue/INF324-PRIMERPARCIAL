<?php
    include("cabecera.php");
    $ci=$_GET["ci"];
    $nroc=$_GET['nrocuenta'];
    $error=$_GET['error'];
?>
    <div class="container">
        <h1>Formulario para hacer una transaccion</h1>
        <form action="guardarT.php" method="GET">
            <div class="form-group">
                <label for="exampleFormControlInput1">Monto</label>
                <input type="number" class="form-control" id="monto" name="monto"/>
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">Tipo</label>
                <select class="form-control" id="tipo" name="tipo">
                <option>Retiro</option>
                <option>Deposito</option>
                </select>
            </div>
            <input type="hidden" name="ci" value="<?php echo $ci;?>">
            <input type="hidden" name="nrocuenta" value="<?php echo $nroc;?>">
            <input type="submit" class="btn btn-primary" value="Aceptar" name="Aceptar"/>
            <input type="submit" class="btn btn-primary" value="Cancelar" name="Cancelar"/>
        </form>
        <h3 id="alerta"><?php if($error=='si'){
            echo "Monto insuficiente para el retiro";
        }?></h3>
    </div>
<?php
    include("pie.php");
?>