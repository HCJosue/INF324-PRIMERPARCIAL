<?php
    include "conexion.php";
    $ci=$_GET["ci"];
    $resultado=mysqli_query($con,"select * from persona where ci=$ci");
    $fila=mysqli_fetch_array($resultado);
    $usuario=$fila["nombre"].'123';
    $pass=md5($fila["paterno"]);
    $resultado=mysqli_query($con,"select * from usuario where nro=$ci");
    if(isset($resultado)){
        mysqli_query($con,"insert into usuario values($ci,'$usuario','$pass',2)");
    }
    header("Location: index.php");
?>