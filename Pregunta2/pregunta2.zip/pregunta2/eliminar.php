<?php
include "conexion.php";
$ci=$_GET["ci"];
mysqli_query($con,"UPDATE persona set estado=0 where ci='$ci'");
header("Location: index.php");
?>