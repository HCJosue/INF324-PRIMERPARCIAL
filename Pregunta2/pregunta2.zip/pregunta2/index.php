<?php 
    include "cabecera.php";
?>
    <div class="Container">
    <h1>Tabla de Personas</h1>
    <div class="card">
        <div class="card-body">
            <a href='Agregar.php'><i class="fa-solid fa-user-plus fa-2xl" style="color: #000224;"></i></a> 
        </div>
    </div>
    <table class="table">
        <thead class="thead-dark">
            <tr>
            <th scope="col">Numero de carnet</th>
            <th scope="col">Nombre</th>
            <th scope="col">Paterno</th>
            <th scope="col">Edad</th>
            <th scope="col">Extension</th>
            <th scope="col">Operaciones</th>
            <th scope="col">Ver cuentas</th>
            <th scope="col">Tiene una cuenta?</th>
            </tr>
        </thead>
        <tbody>
        <?php
        include "conexion.php";
        $eliminar='<i class="fa-solid fa-trash fa-2xl" style="color: #ff0000;"></i>';
        $editar='<i class="fa-solid fa-file-pen fa-2xl" style="color: #00ffbf;"></i>';
        $ver='<i class="fa-solid fa-eye fa-2xl" style="color: #8000ff;"></i>';
        $correcto='<i class="fa-solid fa-circle-check fa-2xl" style="color: #02f2aa;"></i>';
        $incorrecto='<i class="fa-solid fa-triangle-exclamation fa-2xl" style="color: #1b0255;"></i>';
        $resultado=mysqli_query($con,"select * from persona where estado=1");
        $resultado2=mysqli_query($con,"select nro from usuario");
        $os=array();
        while($fila2=mysqli_fetch_array($resultado2)){
            array_push($os,$fila2['nro']);
        }
        while($fila=mysqli_fetch_array($resultado)){
            if(in_array($fila["ci"],$os)){
                $cierto=$correcto;
                $crear='';
            }
            else{
                $cierto=$incorrecto;
                $crear='<i class="fa-regular fa-user fa-2xl" style="color: #f08c00;"></i>';
            }
            echo "<tr>";
            echo "<td>".$fila["ci"]."</td><td>".$fila["nombre"]."</td><td>".$fila["paterno"]."</td><td>".$fila["edad"]."</td><td>".$fila["extension"]."</td>";
            echo "<td><a href='editar.php?ci=$fila[ci]'>$editar</a>";
            echo "<a href='eliminar.php?ci=$fila[ci]'>$eliminar </a><a href='crear.php?ci=$fila[ci]'>$crear</a></td><td>";
            echo "<a href=verc.php?ci=$fila[ci]>$ver</a></td>";
            echo "<td>$cierto</td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
    </div>
<?
    include "pie.php";
?>