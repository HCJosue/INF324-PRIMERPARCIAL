<?php
include "conexion.php";
$nro=$_GET["nrocuenta"];
mysqli_query($con,"UPDATE cuentabancaria set estado=0 where nrocuenta='$nro'");
$resultado=mysqli_query($con,"select * from cuentabancaria where nrocuenta='$nro'");
$fila=mysqli_fetch_array($resultado);
header("Location: verc.php?ci=".$fila['ciUsuario']);
?>