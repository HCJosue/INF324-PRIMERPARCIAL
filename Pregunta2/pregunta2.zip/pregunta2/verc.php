<?php
    include "cabecera.php";
    include "conexion.php";
    $ci=$_GET["ci"];
    $resultado=mysqli_query($con,"select * from persona where ci=$ci");
    $fila=mysqli_fetch_array($resultado);
?>
    <div class="Container">
    <h1>Cuentas de <?php echo $fila["nombre"].' '.$fila["paterno"]?></h1>
    <div class="card">
        <div class="card-body">
            <a href='AgregarC.php?ci=<?php echo $ci;?>'><i class="fa-regular fa-money-bill-1 fa-2xl"></i></a> 
            <a href="index.php"><i class="fa-solid fa-backward fa-2xl" style="color: #031d49;"></i></a>
        </div>
    </div>
    <table class="table">
        <thead class="thead-dark">
            <tr>
            <th scope="col">Numero de cuenta</th>
            <th scope="col">Tipo</th>
            <th scope="col">monto</th>
            <th scope="col">Fecha de Creacion</th>
            <th scope="col">Operacion</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $resultado=mysqli_query($con,"select * from cuentabancaria where ciUsuario=$ci and estado=1");
                $eliminar='<i class="fa-solid fa-trash fa-2xl" style="color: #ff0000;"></i>';;
                while($fila=mysqli_fetch_array($resultado)){
                    echo "<tr>";
                    echo "<td>".$fila["nroCuenta"]."</td><td>".$fila["tipo"]."</td><td>".$fila["monto"]."</td><td>".$fila["fechaA"]."</td>";
                    echo "<td><a href='eliminarC.php?nrocuenta=$fila[nroCuenta]'>$eliminar </a></td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
    </div>
<?
    include "pie.php";
?>