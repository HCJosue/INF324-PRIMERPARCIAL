<?php
    include "conexion.php";
    if (isset($_GET["Cancelar"]))
        header("Location: index.php");
    $ci=$_GET["ci"];
    $nombre=$_GET["nombre"];
    $paterno=$_GET["paterno"];
    $edad=$_GET["edad"];
    $extension=$_GET["extension"];    
    mysqli_query($con,"insert into persona values($ci,'$nombre','$paterno','$extension',$edad,1)");
    header("Location: index.php");
?>