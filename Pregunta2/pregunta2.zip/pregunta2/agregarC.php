<?php
    include "cabecera.php";
    include "conexion.php";
    $ci=$_GET["ci"];
    $resultado=mysqli_query($con,"select * from persona where ci=$ci");
    $fila=mysqli_fetch_array($resultado);
    $fecha=date('Y-n-j');
?>  
    <div class="container">
    <h1>Formulario para agregar una cuenta para <?php echo $fila["nombre"].' '.$fila["paterno"]?></h1>
    <form action="agregarcguardar.php" method="GET">
        <div class="form-group">
            <label for="exampleFormControlSelect1">Tipo</label>
            <select class="form-control" id="tipo" name="tipo">
            <option>Ahorro</option>
            <option>Corriente</option>
            <option>Plazo fijo</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Monto</label>
            <input type="number" class="form-control" id="monto" name="monto"/>
        </div>
        <input type="hidden" name="ci" value="<?php echo $ci;?>" />
        <input type="submit" class="btn btn-primary" value="Aceptar" name="Aceptar"/>
        <input type="submit" class="btn btn-primary" value="Cancelar" name="Cancelar"/>
    </form>
    <div>
<?php
    include "pie.php";
?>