<?php 
include "cabecera.php";
?>
    
    <div class="Container">
    <div class="card">
        <div class="card-header">
            <h1>Cuenta de Ahorro</h1>
        </div>
        <div class="card-body">
            <blockquote class="blockquote mb-0">
            <p>Las cuentas de ahorro te permiten generar una pequeña rentabilidad sobre el dinero que guardas en ellas. Pero como su nombre lo indica, estas cuentas están destinadas a ahorrar dinero, por lo tanto, puede que exista un límite en la cantidad de retiros o transferencias que puedes realizar en un mes y, por lo general, existe un requisito de saldo mínimo diario.</p>
            </blockquote>
        </div>
    </div>
    </div>
  
<?php
    include "pie.php";
?> 