<?php 
    include "cabecera.php";
?>
    <div class="Container">
    <div class="card">
        <div class="card-header">
            <h1>Cuenta corriente</h1>
        </div>
        <div class="card-body">
            <blockquote class="blockquote mb-0">
            <p>Las cuentas corrientes son la opción principal para la gestión diaria de tu dinero. Puedes realizar transacciones frecuentes, como pagar facturas y hacer compras, utilizando cheques o tarjetas de débito asociadas. Estas cuentas generalmente no generan intereses y pueden tener tarifas de mantenimiento mensuales.</p>
            </blockquote>
        </div>
    </div>
    </div>
<?
    include "pie.php";
?>