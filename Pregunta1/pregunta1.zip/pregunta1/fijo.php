<?php 
include "cabecera.php";
?>
    
    <div class="Container">
    <div class="card">
        <div class="card-header">
            <h1>Cuenta de plazo fijo</h1>
        </div>
        <div class="card-body">
            <blockquote class="blockquote mb-0">
            <p>Es una cuenta de ahorro en la cual depositas tu dinero y no puedes retirarlo o gastarlo hasta haber cumplido el plazo fijado por ti y el banco, los ahorros de plazo fijo pueden ir desde los 6 meses hasta más de 3 años, aproximadamente.

<br/>El beneficio de este tipo de cuenta es brindar un porcentaje mayor de intereses, contar con un vehículo seguro de inversión y mantener seguro tu ahorro frente a gastos de compras impulsivas.</p>
            </blockquote>
        </div>
    </div>
    </div>
  
<?php
    include "pie.php";
?> 