﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        ServiceReference1.WebService1SoapClient ws = new ServiceReference1.WebService1SoapClient();
        int CIG;
        public Form3(String ci,String nombre,String paterno,String edad)
        {
            InitializeComponent();
            textBox1.Text = nombre;
            textBox2.Text = paterno;
            textBox3.Text = edad;
            CIG = Convert.ToInt32(ci);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String nombrec = textBox1.Text;
            String paternoc = textBox2.Text;
            int edadc = Convert.ToInt32(textBox3.Text);
            ws.actualizar(CIG,nombrec,paternoc,edadc);
            this.Close();
        }
    }
}
