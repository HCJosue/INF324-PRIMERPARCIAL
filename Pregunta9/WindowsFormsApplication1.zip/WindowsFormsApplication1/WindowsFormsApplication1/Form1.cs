﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        ServiceReference1.WebService1SoapClient ws = new ServiceReference1.WebService1SoapClient();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = ws.dspersona().Tables["persona"];
            //en la web dataGridView1.databind()
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int nrofila = e.RowIndex;
            int ci = Convert.ToInt32(this.dataGridView1.Rows[nrofila].Cells[0].Value);
            MessageBoxButtons f = MessageBoxButtons.YesNo;
            DialogResult t = MessageBox.Show("Desea eliminar la persona con " + ci, "Eliminar", f);
            if (t == DialogResult.Yes)
            {
                ws.eliminar(ci);
                this.dataGridView1.DataSource = ws.dspersona().Tables["persona"];
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.ShowDialog();
            this.dataGridView1.DataSource = ws.dspersona().Tables["persona"];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                String ci = this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                String nombre = this.dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                String paterno = this.dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                String edad = this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                Form3 f = new Form3(ci,nombre,paterno,edad);
                f.ShowDialog();
                this.dataGridView1.DataSource = ws.dspersona().Tables["persona"];

            }
            catch
            {
                MessageBox.Show("Selecciona una fila por favor");
            }
            
        }
    
    }
}
