		<div class="container">
			<h1>Tabla de la cuentas</h1>
		<table class="table">
			<thead class="thead-dark">
				<tr>
				<th scope="col">Numero de cuenta</th>
				<th scope="col">Tipo</th>
				<th scope="col">Monto</th>
				<th scope="col">Operacion</th>
				</tr>
			</thead>
			<tbody>
		<?php
			//echo "identificador: ".$identificador;
			//echo "<br>";
			//print_r($alumnos)

			foreach($cuentas as $cuenta){
				//print_r($alumno);
				echo "<tr>";
				echo "<td>";
				echo $cuenta->nrocuenta;
				echo "</td>";
				echo "<td>";
				echo $cuenta->tipo;
				echo "</td>";
				echo "<td>";
				echo $cuenta->monto;
				echo "</td>";
				echo "<td><a href='http://127.0.0.1/pregunta5/index.php/welcome/eliminar/$cuenta->nrocuenta'><i class='fa-solid fa-trash fa-2xl' style='color: #ff0000;'></i></a></td>";
				echo "</tr>";
			}
			//print_r($datos2);
		?>	
		</tbody>
		</table>  
		</div>


