<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct(){
        parent::__construct();
		$this->load->model('mdatos','',TRUE);
    }
	
	public function eliminar($nro){
		$this->mdatos->desactiva($nro);
		header("Location: http://127.0.0.1/pregunta5/");
	}

	public function index()
	{
		$datos["cuentas"]=$this->mdatos->consulta_cuentas()->result();
		//$datos["datos2"]=$this->mdatos->consulta_uno($id)->row();;
		$this->load->view('cabecera');
		$this->load->view('contenido',$datos);
		$this->load->view('pie');
	}
	
	public function index2()
	{
		$this->load->view('welcome_message2');
	}
	
	public function index3()
	{	
		$datos["cuentas"]=$this->mdatos->consulta_cuentas()->result();
		//$datos["datos2"]=$this->mdatos->consulta_uno($id)->row();;
		$this->load->view('cabecera');
		$this->load->view('contenido',$datos);
		$this->load->view('pie');
	}
	
}
