<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class mdatos extends CI_Model {
    function __construct(){
        parent::__construct();
    }

    function consulta_todos(){
        $sql="Select * from alumno";
        $query=$this->db->query($sql);
        return $query;
    }

    function consulta_cuentas(){
        $sql="Select nrocuenta,tipo,monto from cuentabancaria where estado=1";
        $query=$this->db->query($sql);
        return $query;
    }
    function desactiva($id){
        $sql="UPDATE cuentabancaria set estado=0 where nrocuenta=".$id;
        $query=$this->db->query($sql);
    }
    function consulta_uno($id){
        $this->db->where('id',$id);
        return $this->db->get("alumno");;
    }    

}
?>