<?php 
    include "cabecera.php";
?>
    <div class="container">
        <div class="container-xxl">
            <h1>Formulario para mandar a Java</h1>
            <div class="container-md">
                <form action="http://localhost:8084/WebApplication1/NewServlet" method="GET">
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Nombre</label>
                        <input type="text" class="form-control" id="nombre" name="nombre"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Paterno</label>
                        <input type="text" class="form-control" id="apellido" name="apellido"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Edad</label>
                        <input type="number" class="form-control" id="edad" name="edad"/>
                    </div>
                    <input type="submit" class="btn btn-primary" value="Aceptar" name="Aceptar"/>
                </form>
            </div>
        </div>
        <div class="container-xxl">
            <h1>Formulario para mandar a NET</h1>
            <div class="container-md">
                <form action="https://localhost:44380/WebForm1.aspx" method="GET">
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Nombre</label>
                        <input type="text" class="form-control" id="nombre" name="nombre"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Paterno</label>
                        <input type="text" class="form-control" id="apellido" name="apellido"/>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Edad</label>
                        <input type="number" class="form-control" id="edad" name="edad"/>
                    </div>
                    <input type="submit" class="btn btn-primary" value="Aceptar" name="Aceptar"/>
                </form>
            </div>
        </div>
    </div>
<?
    include "pie.php";
?>